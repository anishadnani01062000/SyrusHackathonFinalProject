package com.example.anish.yourtaskapp.UserLoginFiles;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RelativeLayout;

import com.applozic.mobicommons.commons.core.utils.Utils;
import com.example.anish.yourtaskapp.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

import io.kommunicate.KmChatBuilder;
import io.kommunicate.Kommunicate;
import io.kommunicate.callbacks.KmCallback;
import io.kommunicate.users.KMUser;

public class Chat2Activity extends AppCompatActivity {

    private DatabaseReference myDatabase;
    //private FirebaseAuth mAuth;

    private RelativeLayout lay1;
    private RelativeLayout lay2;
    private RelativeLayout lay3;
    private RelativeLayout lay4;
    private RelativeLayout lay5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat2);

        //mAuth=FirebaseAuth.getInstance();


        ///////////

        lay1=findViewById(R.id.home1);
        lay2=findViewById(R.id.file1);
        lay3=findViewById(R.id.contact1);
        lay4=findViewById(R.id.chat1);
        lay5=findViewById(R.id.stats1);
        ////////
        myDatabase=FirebaseDatabase.getInstance().getReference("Mess");




        //final TextView mytext = findViewById(R.id.textboxasli);
//////////


        // niche ka code //////////////////////

/*
        lay1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            }
        });
        lay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), FileActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), FileActivity.class));
            }
        });
        lay3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), ContactActivity.class));
            }
        });
        lay4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Chat2Activity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), ChatActivity.class));
            }
        });
        lay5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), StatsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), StatsActivity.class));
            }
        });

*/
        ///////////////////////////////////CHATBOT TRY SCENE/////////////////////////////////////////
        Kommunicate.init(getApplicationContext(), "290b464bec4c620383b09fc6500d1b02");


       /* List<String> agentList = new ArrayList();
        agentList.add("anishadnani007@gmail.com"); //add your agentID

        List<String> botList = new ArrayList();
        botList.add("liz"); //enter your integrated bot Idsl

        Kommunicate.launchSingleChat(getApplicationContext(), "Support", Kommunicate.getVisitor(), false, true, agentList, botList, new KmCallback(){
            @Override
            public void onSuccess(Object message) {
               // Log.d(getApplicationContext(), "ChatLaunch", "Success : " + message);
                Toast.makeText(getApplicationContext(), "Success", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Object error) {
              //  Log.d(context, "ChatLaunch", "Failure : " + error);
                Toast.makeText(getApplicationContext(),"Failure",Toast.LENGTH_LONG).show();
            }
        });*/
        ///////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////

        new KmChatBuilder(getApplicationContext()).launchChat(new KmCallback() {
            @Override
            public void onSuccess(Object message) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Success : " + message);
            }

            @Override
            public void onFailure(Object error) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Failure : " + error);
            }
        });


        List<String> agentList = new ArrayList();
        agentList.add("anishadnani007@gmail.com"); //add your agentID. The agentId id the email id you have used to signup on kommunicate dashboard

        List<String> botList = new ArrayList();
        botList.add("smart-cop"); //Go to bots(https://dashboard.kommunicate.io/bot) -> Integrated bots -> Copy botID

        new KmChatBuilder(getApplicationContext()).setAgentIds(agentList).setBotIds(botList).launchChat(new KmCallback() {
            @Override
            public void onSuccess(Object message) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Success : " + message);
            }

            @Override
            public void onFailure(Object error) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Failure : " + error);
            }
        });


        new KmChatBuilder(Chat2Activity.this).setWithPreChat(true).launchChat(new KmCallback() {
            @Override
            public void onSuccess(Object message) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Success : " + message);
            }

            @Override
            public void onFailure(Object error) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Failure : " + error);
            }
        });

        KMUser user = new KMUser();
        user.setUserId("1019"); // Pass a unique key
        //user.setImageLink(""); // Optiona

        new KmChatBuilder(Chat2Activity.this).setKmUser(user).launchChat(new KmCallback() {
            @Override
            public void onSuccess(Object message) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Success : " + message);
            }

            @Override
            public void onFailure(Object error) {
                Utils.printLog(Chat2Activity.this, "ChatTest", "Failure : " + error);
            }
        });

        ////////////////////////

      /*  myDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                mytext.setText(dataSnapshot.getValue().toString());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

                mytext.setText("CANCELED");

            }
        });
    }

    public void sendMessage(View view){

        EditText myEditText = findViewById(R.id.edittext);
        myDatabase.child("Name").setValue(myEditText.getText().toString());

        Toast.makeText(getApplicationContext(), "You will be replied via mail within an hour", Toast.LENGTH_LONG).show();

        myEditText.setText("");

*/

    }

}
