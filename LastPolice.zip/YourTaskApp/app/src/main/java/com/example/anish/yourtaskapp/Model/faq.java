package com.example.anish.yourtaskapp.Model;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.anish.yourtaskapp.UserLoginFiles.QuestionLibrary;
import com.example.anish.yourtaskapp.R;

public class faq extends Fragment {
    private QuestionLibrary mQuestionLibrary=new QuestionLibrary();
    private TextView mScoreView;
    private TextView mQuestionView;
    private Button mButtonChoice1;
    private Button mButtonChoice2;
    private LinearLayout mLinear1;
    private LinearLayout mLinear2;

    private TextView dScore;
    private Button dButton;


    private String mAnswer;
    private int mScore=0;
    private int mQuestionNumber=0;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.faq,container, false);
        mScoreView=rootView.findViewById(R.id.score);
        mQuestionView=rootView.findViewById(R.id.question);
        mButtonChoice1=rootView.findViewById(R.id.choice1);
        mButtonChoice2=rootView.findViewById(R.id.choice2);
        mLinear1=rootView.findViewById(R.id.mcq_take);
        mLinear2=rootView.findViewById(R.id.result_page);
        dScore=rootView.findViewById(R.id.result_score) ;
        dButton=rootView.findViewById(R.id.retake);
        mQuestionNumber=0;
        start();
        //Radio1 ke options

        return rootView;
    }
    private void start(){
        updateQuestion();
        mButtonChoice1.setOnClickListener (new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if( mButtonChoice1.getText()==mAnswer && mQuestionNumber<10){
                    mScore=mScore+1;

                    updateScore(mScore);
                    updateQuestion();
                    Toast.makeText(getActivity(),"Correct",Toast.LENGTH_SHORT).show();

                } else if(mQuestionNumber==10) {

                    if( mButtonChoice1.getText()==mAnswer){
                        mScore=mScore+1;
                        Toast.makeText(getActivity(),"Correct",Toast.LENGTH_SHORT).show();

                    }


                    Toast.makeText(getActivity(),"Successful",Toast.LENGTH_SHORT).show();
                    mLinear1.setVisibility(View.GONE);
                    mLinear2.setVisibility(View.VISIBLE);
                    dScore.setText("Your SCORE is "+mScore);


                    dButton.setOnClickListener(new View.OnClickListener(){

                        @Override
                        public void onClick(View v) {
                            reload();
                        }
                    });

                }

                else{
                    Toast.makeText(getActivity(),"Wrong",Toast.LENGTH_SHORT).show();
                    updateQuestion();

                }
            }
        });

        mButtonChoice2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if( mButtonChoice2.getText()==mAnswer && mQuestionNumber<10){
                    mScore=mScore+1;
                    updateScore(mScore);
                    updateQuestion();
                    Toast.makeText(getActivity(),"Correct",Toast.LENGTH_SHORT).show();

                }
                else if(mQuestionNumber==10) {
                    Toast.makeText(getActivity(),"Successful",Toast.LENGTH_SHORT).show();
                    mLinear1.setVisibility(View.GONE);
                    mLinear2.setVisibility(View.VISIBLE);
                    dScore.setText("Your SCORE is "+mScore);


                    dButton.setOnClickListener(new View.OnClickListener(){
                        @Override
                        public void onClick(View v) {
                        reload();
                        }
                    });


                }else
                {
                    Toast.makeText(getActivity(),"Wrong",Toast.LENGTH_SHORT).show();
                    updateQuestion();

                }
            }
        });
    }
    private void updateQuestion(){

        mQuestionView.setText(mQuestionLibrary.getQuestion(mQuestionNumber));
        mButtonChoice1.setText(mQuestionLibrary.getChoice1(mQuestionNumber));
        mButtonChoice2.setText(mQuestionLibrary.getChoice2(mQuestionNumber));

        mAnswer = mQuestionLibrary.getCorrectAnswer(mQuestionNumber);
        mQuestionNumber++;
    }

    private void updateScore(int point){
        mScoreView.setText(""+mScore);
    }
    private void reload(){
        mScore=0;
        mQuestionNumber=0;
        updateScore(mScore);
        mLinear1.setVisibility(View.VISIBLE);
        mLinear2.setVisibility(View.GONE);
        start();
    }
}
