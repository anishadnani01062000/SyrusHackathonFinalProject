package com.example.anish.yourtaskapp.UserLoginFiles;

public class QuestionLibrary {
    private String mQuestion[]={
            "_____ give introduction to an unknown person for opening an account in your Bank.",
            "_____ encash cheques/drafts of an unknown person through your account.",
            "_____ accept any parcel from strangers.",
            "_____ provide your credit card number to anyone who con\u00ADtacts you through telephone solicitation.",
            "_____ keep valuables, purses, mobile phones, and wristwatches openly visible from outside.",
            "_____ inform the Police about any suspicious happening or unclaimed object found in suspicious circumstances.",
            "_____ the antecedents / credentials of chowkidars and domestic servants before hiring them. Insist on references from their previous employers.",
            "_____ accept identification marks on its face value.",
            "_____ give information over the phone to someone you don't know.",
            "_____ deposit slips before beginning your transaction and not in plain view."
    };
    private String mchoices[][]={
            {"Do","Dont"},
            {"Do","Dont"},
            {"Do","Dont"},
            {"Do","Dont"},
            {"Do","Dont"},
            {"Do","Dont"},
            {"Check","Dont CHeck"},
            {"Do","Dont"},
            {"Do","Dont"},
            {"Fill","Dont FIll"}
    };
    private String mCorrectAnswer[]={
      "Dont",
      "Dont",
      "Dont",
      "Dont",
      "Dont",
      "Do",
      "Check",
      "Dont",
      "Dont",
      "Fill"
    };

    public String getQuestion(int a){
        String question=mQuestion[a];
        return question;
    }

    public String getChoice1(int a){
        String choice0=mchoices[a][0];
        return choice0;
    }

    public String getChoice2(int a){
        String choice1=mchoices[a][1];
        return choice1;
    }

    public String getCorrectAnswer(int a){
        String answer=mCorrectAnswer[a];
        return answer;
    }
}
